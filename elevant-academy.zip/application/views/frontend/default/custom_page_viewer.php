<div class="container-xl">
	<?php echo remove_js(htmlspecialchars_decode($page_content)); ?>
</div>